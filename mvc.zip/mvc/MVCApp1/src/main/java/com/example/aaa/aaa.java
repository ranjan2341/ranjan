package com.example.aaa;

import org.springframework.jdbc.core.JdbcTemplate;

public class aaa {
	private JdbcTemplate jt;

}
