package com.nt.service;

import java.util.List;

public interface LanguageService {
	public List<String> getLanguages();

}
