package com.nt.dao;

import com.nt.domain.StudentHLO;

public interface StudentInsertDAO {
   public int  insert(StudentHLO hlo);
}
