package com.nt.dao;

import java.util.List;

import com.nt.bo.ProfileBO;

public interface FBProfileDAO {
	public List<ProfileBO> getAllProfiles();
	

}
