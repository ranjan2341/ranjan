package com.nt.service;

import java.util.List;

import com.nt.dto.ProfileDTO;

public interface FBProfileService {
	public List<ProfileDTO> fetchAllProfiles();

}
