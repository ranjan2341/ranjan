package com.nt.controller;


import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InboxController {

	@RequestMapping("/home.htm")
	public String showHomePage() {
		return "home";
	}
	
	@RequestMapping("/inbox.htm")
	public String showInbox(Map<String,Object> map){
		return "inbox";
	}

}
