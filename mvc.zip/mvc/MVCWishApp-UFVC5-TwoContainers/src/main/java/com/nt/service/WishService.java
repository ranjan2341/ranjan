package com.nt.service;

public interface WishService {
	
	public String generateWishService();

}
