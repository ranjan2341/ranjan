package com.nt.service;

import java.util.List;

import com.nt.dto.EmployeeDTO;

public interface ListEmployeeService {
	
	public List<EmployeeDTO> getAllEmployess();

}
