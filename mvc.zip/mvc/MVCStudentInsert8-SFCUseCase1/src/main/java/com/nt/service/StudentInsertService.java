package com.nt.service;

import com.nt.dto.StudentDTO;

public interface StudentInsertService {
	
	public  String register(StudentDTO dto);

}
