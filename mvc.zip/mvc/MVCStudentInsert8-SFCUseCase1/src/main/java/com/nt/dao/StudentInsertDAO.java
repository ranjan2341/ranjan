package com.nt.dao;

import com.nt.bo.StudentBO;

public interface StudentInsertDAO {
	public int insert(StudentBO bo);

}
