package com.nt.service;

import java.util.List;

public interface ListUploadedFileService {
   public List<String> listAllFiles();
}
