package com.nt.test;

public class Test {
   private Test(){
	   System.out.println("Test:0-param consturctor");
   }
   
   public String toString(){
	   return "hello";
   }
}
