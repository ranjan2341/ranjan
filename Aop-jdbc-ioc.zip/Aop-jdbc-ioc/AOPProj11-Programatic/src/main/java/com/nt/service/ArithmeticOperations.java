package com.nt.service;

public class ArithmeticOperations {
	
	public int sum(int x,int y){
		return x+y;
	}
	public int sub(int x,int y){
		return x-y;
	}
	public int mul(int x,int y){
		return x*y;
	}
}
