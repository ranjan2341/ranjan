package com.nt.service;

public interface StudentService {
	
	public  int  findStudentsCount();

}
