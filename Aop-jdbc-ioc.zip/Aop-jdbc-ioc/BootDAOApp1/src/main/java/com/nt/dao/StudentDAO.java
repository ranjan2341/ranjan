package com.nt.dao;

public interface StudentDAO {
   public int getStudentsCount();
}
