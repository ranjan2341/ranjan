package com.nt.service;

public interface BankLoanApproverInterface {
	public String approveLoan(int loanId,String type);
}
