package com.nt.service;

public class ShoppingMall {
	
	public float shopping(String items[],float range){
		 
		return items.length*range;
		
	}

}
