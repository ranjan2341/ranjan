package com.nt.service;

import java.util.List;

import com.nt.dto.PassengerDTO;

public interface GroupReservationService {
	public String groupReservation(List<PassengerDTO> listDTO);

}
