package com.nt.dao;

public interface DepositeDAO {
	public int deposite(int accNo,int amt);

}
