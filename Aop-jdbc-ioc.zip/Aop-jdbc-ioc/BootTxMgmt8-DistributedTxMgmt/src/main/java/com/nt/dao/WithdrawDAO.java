package com.nt.dao;

public interface WithdrawDAO {
	public int withdraw(int accNo,int amt);

}
