package com.nt.service;

public interface TransferMoneyService {
  public boolean transferMoney(int srcAcNo,int destAcNo,int amt);	

}
