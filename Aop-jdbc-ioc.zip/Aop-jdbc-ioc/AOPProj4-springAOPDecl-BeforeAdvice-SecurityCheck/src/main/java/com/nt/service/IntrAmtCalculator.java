package com.nt.service;

public interface IntrAmtCalculator {
	public float calcIntrAmount(float pAmt,float time,float rate);
}
