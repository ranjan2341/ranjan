package com.nt.service;

public interface IntrAmtCalculatorInterface {
	
	public float  calcIntrAmt(float pAmt,float time,float rate);

}
