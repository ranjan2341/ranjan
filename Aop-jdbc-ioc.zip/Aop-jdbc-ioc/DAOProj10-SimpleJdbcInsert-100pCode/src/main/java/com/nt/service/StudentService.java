package com.nt.service;

import com.nt.dto.StudentDTO;

public interface StudentService {
	
	public  String registerStudent(StudentDTO dto);

}
