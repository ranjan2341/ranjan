package com.nt.dao;

public interface AuthenticateDAO {
	public String authenticate(String user,String pwd);

}
