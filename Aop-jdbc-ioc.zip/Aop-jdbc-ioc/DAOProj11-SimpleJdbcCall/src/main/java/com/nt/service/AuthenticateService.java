package com.nt.service;

public interface AuthenticateService {
	
	public  String validate(String uname,String pwd);

}
