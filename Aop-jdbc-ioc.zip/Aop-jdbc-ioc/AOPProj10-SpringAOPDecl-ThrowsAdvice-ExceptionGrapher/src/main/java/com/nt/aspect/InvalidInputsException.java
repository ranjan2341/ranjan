package com.nt.aspect;

public class InvalidInputsException extends RuntimeException {
	
	public InvalidInputsException(String msg) {
		super(msg);
	}

}
